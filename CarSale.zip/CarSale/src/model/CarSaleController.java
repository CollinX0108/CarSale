package model;

import java.util.ArrayList;

public class CarSaleController {

	private ArrayList<Vehicule> vehiculess ;
	private int[][] documents ;
	private Vehicule[][] parking ;

	public CarSaleController() {
	
		vehiculess = new ArrayList<Vehicule>();
		documents = new int[4][4] ;
		parking = new Vehicule[10][5] ;

	}

	public String showVehiculeList() {

		String vehiculeRegistered = "";

		for (int i = 0; (i < vehiculess.size()); i++) {

			if (vehiculess.get(i) != null) {

				vehiculeRegistered += "\n" + (i + 1) + ". ";

				vehiculeRegistered += vehiculess.toString();
				
			}

		}

		return vehiculeRegistered;

	}
	
	public String showAllVehiculeData() {

		String vehiculeRegistered = "";

		for (int i = 0; (i < vehiculess.size()); i++) {

			if (vehiculess.get(i) != null) {

				vehiculeRegistered += "\n" + (i + 1) + ". ";

				vehiculeRegistered += vehiculess.toString() ;
				
			}

		}

		return vehiculeRegistered;

	}
	
	public String showVehiculeDocumentStatus(int id) {

		String vehiculeRegistered = "";

		if (vehiculess.get(id) != null) {
			
			vehiculeRegistered = "Vehicule brand: " + vehiculess.get(id).getBrand() + "\n" + "\nDocuments summary: " +  "\n" + showDocumentMatrix(vehiculess.get(id).getDocument().getImage()) + "\nCode: " + vehiculess.get(id).getDocument().getCode() + "\nYear: " + vehiculess.get(id).getDocument().getYear() ;
			

		}

		return vehiculeRegistered;
		
		

	}
	
	public double showVehiculeTotalPrice(int i, int desition, double aditional) {

		double total = 0 ;

		if (vehiculess.get(i) != null) {
			
			total = vehiculess.get(i).getBasePrice() ; 
			
			if (vehiculess.get(i).getDocument().getYear() != 2022) {
				total = total + 500000;
			}
			
			if (vehiculess.get(i) instanceof ElectricCar) {
				total = total + (vehiculess.get(i).getBasePrice()*0.2);
			}
			
			if (vehiculess.get(i) instanceof HybridCar) {
				total = total + (vehiculess.get(i).getBasePrice()*0.15);
			}
			
			if (vehiculess.get(i) instanceof Car && vehiculess.get(i).getState() == "Used") {
				total = total - (total*0.1);
			}
			
			if (vehiculess.get(i) instanceof Motorcycle) {
				total = total + (total*0.04) ;
			}
			
			if (vehiculess.get(i) instanceof Motorcycle && vehiculess.get(i).getState() == "Used") {
				total = total - (total*0.02);
			}
			
			if (desition == 1) {
				total = total - (total*aditional) ;
			}
			

		}

		return total;

	}
	
	public boolean registerElectricCar(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows, String chargeType, double duration, double batteryConsumption) {

		boolean ElectricAdded = false;

		Vehicule myCar = new ElectricCar(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows, chargeType, duration, batteryConsumption) ;

		vehiculess.add(myCar) ;
		
		if(myCar.getState() == "Used" && myCar.getModel() < 2015) {
			addParking(myCar) ;
		}	
		
		ElectricAdded = true;


		return ElectricAdded;
	}
	
	public String addParking(Vehicule temp) {

		String parkingAdded = "";
		
		boolean Continue = true ;
			
		for (int x=0; x < parking.length; x++) {
			
			for (int y=0; y < parking[x].length; y++) {
				
				if(parking[x][y] == null && Continue == true) {
					
					if (temp.getModel()==2014 && y==0) {
				
						parking[x][y] = temp ;
						Continue = false ;
					
					} else if (temp.getModel()==2013 && y==1) {
				
						parking[x][y] = temp ;
						Continue = false ;
					
					} else if (temp.getModel()==2012 && y==2) {
				
						parking[x][y] = temp ;
						Continue = false ;
					
					} else if (temp.getModel()==2011 && y==3) {
				
						parking[x][y] = temp ;
						Continue = false ;
					
					} else if (temp.getModel()<2011 && y==4) {
				
						parking[x][y] = temp ;
						Continue = false ;
					
					}
				
				}
				
				parkingAdded = "Parquedero lleno" ;
				
			}
		
		}

		return parkingAdded;
		
	}
	
	public boolean registerGasolineCar(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows, double tankCapacity, String gasolineType, double gasolineConsumption) {
		
		boolean GasolineAdded = false;
		
		Vehicule myCar = new GasolineCar(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows, tankCapacity, gasolineType, gasolineConsumption) ;

		vehiculess.add(myCar) ;
		
		if(myCar.getState() == "Used" && myCar.getModel() < 2015) {
			addParking(myCar) ;
		}	
		
		GasolineAdded = true;
		
		return GasolineAdded;
		
		
	}
	
	public boolean registerHybridCar(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows, double tankCapacity, String gasolineType, double gasolineConsumption, String chargeType, double duration, double batteryConsumption) {

		boolean HybridAdded = false;
		
		Vehicule myCar = new HybridCar(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows, tankCapacity, gasolineType, gasolineConsumption, chargeType, duration, batteryConsumption);

		vehiculess.add(myCar) ;
		
		if(myCar.getState() == "Used" && myCar.getModel() < 2015) {
			addParking(myCar) ;
		}	
		
		HybridAdded = true;
		
		return HybridAdded;

	}
	
	public boolean registerMotorcycle(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, double capacity, double fuelUse) {

		boolean MotorcycleAdded = false;

		Vehicule myMotorcycle = new Motorcycle(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, capacity, fuelUse) ;

		vehiculess.add(myMotorcycle) ;
		
		if(myMotorcycle.getState() == "Used" && myMotorcycle.getModel() < 2015) {
			addParking(myMotorcycle) ;
		}	
		
		MotorcycleAdded = true;


		return MotorcycleAdded;
	}
	
	public int[][] createDocumentMatrix() {
		
		int[][] image;
		
		for (int x=0; x < documents.length; x++) {
			for (int y=0; y < documents[x].length; y++) {
				documents[x][y] = (int)(Math.random()*10);
				
			}
			
		}
		
		image = documents ; 
		
		return image;	
		
	}
	
	public String showDocumentMatrix(int[][] temp) {
		
		String out = "" ;
		
		for (int x=0; x < temp.length; x++) {
			for (int y=0; y < temp[x].length; y++) {
				out += temp[x][y] + " " ; 
			}
			out += "\n" ;	
		}
		
		
		return out ;
		
	}
	
public String showDocumentCode(int choose, int[][] temp) {
		
		String out = "" ;
		
		if (choose == 1) {
		
			for (int x=0; x < temp.length; x++) {
	
				for (int y=0; y < temp[x].length; y++) {
					
					if (y == 0 && x != temp.length-1) {
						out += temp[x][y] + " " ; 
					}
					
					if (x == temp.length-1) {
						
						out += temp[x][y] + " " ; 
						
					}
					
				}
			}
		
		}
		
		if (choose == 2) {
			
			boolean Continue = true ;
			boolean Continue2 = true ;
			
			for (int x=0; x < temp.length; x++) {
				
				for (int y = temp[0].length - 1; y > 0; y--) {
					
					for (int j = 0; j < temp[x].length-1 && Continue == true; j++) {
					
						if (x == 0 && Continue == true) {
							out += temp[x][j] ;
							
						}
						
					
					}
					
					Continue = false ;
					
					if (x + y == 3) {
						out += temp[x][y] ;
					}
					
					if (x == temp.length-1 && Continue2 == true) {
						
						
					
						for (int i = 0;i < temp[x].length; i++) {
						
							
							
							out += temp[x][i] ;
							
							
					
						}
						
						Continue2 = false ;
					
					}
					
				}
				
			}
			
		}
		
		if(choose == 3) {
		
			for (int x=temp.length-1; (x >= 0); x--) {
			
				
			
				for (int y = temp[x].length-1; y >= 0 ; y--) {
				
					if (((x+y)%2)==0 && x+y != 0) { //If you want to take the position [0][0] like an even just delete this part of the conditional (x+y != 0)
						out += temp[x][y] + "" ;
					}
				}
				
				
			}
		
		}
		
		
		return out ;
		
	}

	public String showParkingSlots() {
		
		String parkingSlots = "" ; 
		
		boolean Continue = true ;

		for (int x=0; x < parking.length; x++) {
			
			for (int y=0; y < parking[x].length; y++) {
				
				if (parking[x][y] != null && parking[x][y].getModel() == 2014 && y == 0) {
					parkingSlots += " [" + parking[x][y].toString() + " ] " ;
					Continue = false ;
				} 
				
				if (parking[x][y] != null && parking[x][y].getModel() == 2013 && y == 1) {
					parkingSlots += " [" + parking[x][y].toString() + " ] " ;
					Continue = false ;
				} 
				
				if (parking[x][y] != null && parking[x][y].getModel() == 2012 && y == 2) {
					parkingSlots += " [" + parking[x][y].toString() + " ] " ;
					Continue = false ;
				} 
				
				if (parking[x][y] != null && parking[x][y].getModel() == 2011 && y == 3) {
					parkingSlots += " [" + parking[x][y].toString() + " ] " ;
					Continue = false ;
				}
				
				if (parking[x][y] != null && parking[x][y].getModel() < 2011 && y == 4) {
					parkingSlots += " [" + parking[x][y].toString() + " ] " ;
					Continue = false ;
				}
				
				if (parking[x][y] == null && Continue == true) {
					parkingSlots += " [" + "EMPTY" + " - " + "EMPTY" + " - " + "EMPTY" + "] ";
				} 	
				Continue = true ;
			
			}
			
			parkingSlots += "\n" ;
		}

		return parkingSlots ;
	
	}
	
	public boolean registerSoatDocument(Vehicule temp, double price, int year, int[][] image, double coverageAmount, String code) {

		boolean documentAdded = false;
		
		image = createDocumentMatrix();
		
		Document myDocument = new Soat(code, price, year, image, coverageAmount) ;
		
		if (vehiculess.contains(temp) == true) {
			temp.setDocument(myDocument);
		}	

		documentAdded = true;

		return documentAdded ;
		
	} 

}