package model;

public class Car extends Vehicule {

	private String type ;
	private int door ;
	private boolean hasTintedWindows ;

	public Car(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows) {
		
		super(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image) ;
		
		this.type = type ;
		this.door = door ;
		this.hasTintedWindows = hasTintedWindows ;
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDoor() {
		return door;
	}

	public void setDoor(int door) {
		this.door = door;
	}

	public boolean isHasTintedWindows() {
		return hasTintedWindows;
	}

	public void setHasTintedWindows(boolean hasTintedWindows) {
		this.hasTintedWindows = hasTintedWindows;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	

}