package model;

import java.util.Arrays;

public class Document {
	
	private String code ;
	private double price ;
	private int year ;
	private int[][]image ;
	
	public Document(String code, double price, int year, int[][] image) {
		super();
		
		this.code = code ;
		this.price = price ;
		this.year = year ;
		this.image = image ;
		
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getYear() {
		return year;
	}
 
	public void setYear(int year) {
		this.year = year;
	}

	public int[][] getImage() {
		return image;
	}

	public void setImage(int[][] image) {
		this.image = image;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "Document [price=" + price + ", year=" + year + ", image=" + Arrays.toString(image) + "]";
	}

	
	
	
}
