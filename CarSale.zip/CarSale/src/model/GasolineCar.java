package model;

public class GasolineCar extends Car {

	private double tankCapacity ;
	private String gasolineType ;
	private double gasolineConsumption ;

	public GasolineCar(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows, double tankCapacity, String gasolineType, double gasolineConsumption) {
		
		super(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows) ;
		
		this.tankCapacity = tankCapacity ;
		this.gasolineType = gasolineType ;
		this.gasolineConsumption = gasolineConsumption ;
		
	}

	public double getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(double tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public String getGasolineType() {
		return gasolineType;
	}

	public void setGasolineType(String gasolineType) {
		this.gasolineType = gasolineType;
	}

	public double getGasolineConsumption() {
		return gasolineConsumption;
	}

	public void setGasolineConsumption(double gasolineConsumption) {
		this.gasolineConsumption = gasolineConsumption;
	}
	
	@Override
	public String toString() {
		
		return getBrand() + " - " + getModel() + " - " + getBasePrice() ;
		
	}

}