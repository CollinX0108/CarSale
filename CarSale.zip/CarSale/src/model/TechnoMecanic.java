package model;

public class TechnoMecanic extends Document{
	
	private double gasLevel ;
	
	public TechnoMecanic(String code, double price, int year, int[][] image, double gasLevel) {
		
		super(code, price, year, image) ;
		
		this.gasLevel = gasLevel ;
		
	}

	public double getGasLevel() {
		return gasLevel;
	}

	public void setGasLevel(double gasLevel) {
		this.gasLevel = gasLevel;
	}
	
}
