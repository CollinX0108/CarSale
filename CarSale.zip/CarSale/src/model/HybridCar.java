package model;

public class HybridCar extends Car {

	private double tankCapacity ;
	private String gasolineType ;
	private double gasolineConsumption ;
	private String chargeType ;
	private double duration ;
	private double batteryConsumption ;

	public HybridCar(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows, double tankCapacity, String gasolineType, double gasolineConsumption, String chargeType, double duration, double batteryConsumption) {
		
		super(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows) ;
		
		this.tankCapacity = tankCapacity ;
		this.gasolineType = gasolineType ;
		this.gasolineConsumption = gasolineConsumption ;
		this.chargeType = chargeType ;
		this.duration = duration ;
		this.batteryConsumption = batteryConsumption ;
		
	}

	public double getTankCapacity() {
		return tankCapacity;
	}

	public void setTankCapacity(double tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	public String getGasolineType() {
		return gasolineType;
	}

	public void setGasolineType(String gasolineType) {
		this.gasolineType = gasolineType;
	}

	public double getGasolineConsumption() {
		return gasolineConsumption;
	}

	public void setGasolineConsumption(double gasolineConsumption) {
		this.gasolineConsumption = gasolineConsumption;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getBatteryConsumption() {
		return batteryConsumption;
	}

	public void setBatteryConsumption(double batteryConsumption) {
		this.batteryConsumption = batteryConsumption;
	}
	
	@Override
	public String toString() {
		
		return getBrand() + " - " + getModel() + " - " + getBasePrice() ;
		
	}

}