package model;

public class Soat extends Document{

	private double coverageAmount ;
	private int type ;
	
	public Soat(String code, double price, int year, int[][] image, double coverageAmount) {
		
		super(code, price, year, image) ;
		
		this.type = 1 ;
		this.coverageAmount = coverageAmount ;
		
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	
	
		
}
