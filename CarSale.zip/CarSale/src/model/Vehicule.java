package model;

public abstract class Vehicule {

	private String brand ;
	private int model ;
	private double basePrice ;
	private double additionalDiscount ;
	private double cylinder ;
	private String state ;
	private String plate ;
	private double driven ;
	private Document document;
	
	public Vehicule(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image) {
		super();
		this.brand = brand ;
		this.model = model ;
		this.basePrice = basePrice ;
		this.additionalDiscount = additionalDiscount ;
		this.cylinder = cylinder ;
		this.state = state ;
		this.plate = plate ;
		this.driven = driven ;
		this.document = new Document(code, price, year, image);
		}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public double getAdditionalDiscount() {
		return additionalDiscount;
	}

	public void setAdditionalDiscount(double additionalDiscount) {
		this.additionalDiscount = additionalDiscount;
	}

	public double getCylinder() {
		return cylinder;
	}

	public void setCylinder(double cylinder) {
		this.cylinder = cylinder;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPlate() {
		return plate;
	}

	public void setPlate(String plate) {
		this.plate = plate;
	}

	public double getDriven() {
		return driven;
	}

	public void setDriven(double driven) {
		this.driven = driven;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	@Override
	public abstract String toString();

}
