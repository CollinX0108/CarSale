package model;

public class ElectricCar extends Car {

	private String chargeType ;
	private double duration ;
	private double batteryConsumption ;

	public ElectricCar(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, int door, boolean hasTintedWindows, String chargeType, double duration, double batteryConsumption) {
		
		super(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows) ;
		
		this.chargeType = chargeType ;
		this.duration = duration ;
		this.batteryConsumption = batteryConsumption ;
		
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getBatteryConsumption() {
		return batteryConsumption;
	}

	public void setBatteryConsumption(double batteryConsumption) {
		this.batteryConsumption = batteryConsumption;
	}

	@Override
	public String toString() {
		
		return getBrand() + " - " + getModel() + " - " + getBasePrice() ;
		
	}

}
