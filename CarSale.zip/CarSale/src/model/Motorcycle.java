package model;

public class Motorcycle extends Vehicule {

	private String type ;
	private double capacity ;
	private double fuelUse ;

	public Motorcycle(String brand, int model, double basePrice, double additionalDiscount, double cylinder, String state, String plate, double driven, String code, double price, int year, int[][] image, String type, double capacity, double fuelUse) {
		
		super(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image) ;
		
		this.type = type ;
		this.capacity = capacity ;
		this.fuelUse = fuelUse ;
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	public double getFuelUse() {
		return fuelUse;
	}

	public void setFuelUse(double fuelUse) {
		this.fuelUse = fuelUse;
	}

	@Override
	public String toString() {
		
		return getBrand() + " - " + getModel() + " - " + getBasePrice() + " - " + this.getDocument().getImage() ;

	}

}