package ui;

import java.util.Scanner;

import model.CarSaleController;

public class CarSaleManager {

	public static Scanner reader;
	public static CarSaleController controller;

	public static void main(String[] args) {
		init();
		showMainMenu();
	}

	private static void init() {

		reader = new Scanner(System.in);
		controller = new CarSaleController();
	}

	private static void showMainMenu() {

		System.out.println("Welcome to Car Sale");

		boolean stopFlag = false;

		while (!stopFlag) {

			System.out.println("\nType an option") ;
			System.out.println("1. Register a Vehicule") ;
			System.out.println("2. Show a Vehicule's selling price") ;
			System.out.println("3. Generate All Vehicule's report") ;
			System.out.println("4. Show a Vehicule's document status") ;
			System.out.println("5. Show Parking Garage's map") ;
			System.out.println("6. Generate Parking Garage's reports") ;
			System.out.println("0. Exit");

			int mainOption = reader.nextInt();

			switch (mainOption) {

			case 1:
				registerVehicule();
				break;
			case 2:
				calculateVehiculeTotalPrice() ;  
				break;
			case 3:
				//registerDocument();
				break;
			case 4:
				showVehiculeStatus();
				break;
			case 5:
				showParkingMap();
				break;
			case 6:
				//registerDocument();
				break;
			case 7:
				//prueba(); Vehiculo de prueba para parquedadero
				break;
			case 8:
				//pruebaa(); Vehiculo de prueba para parqueadero
				break;
			case 0:
				System.out.println("Thanks for using our system");
				stopFlag = true;
				break;
			default:
				System.out.println("You must type a valid option");
				break;

			}

		}

	}

	private static void registerVehicule() {
		
		System.out.println("Type the Vehicule brand: ");
		String brand = reader.nextLine();
		brand = reader.nextLine();

		System.out.println("Type the Vehicule model: ");
		int model = reader.nextInt();

		System.out.println("Type the Vehicule base price: ");
		double basePrice = reader.nextDouble();

		System.out.println("Type the Vehicule additional discount: ");
		double additionalDiscount = reader.nextDouble();

		System.out.println("Type the Vehicule cylinder: ");
		double cylinder = reader.nextDouble();
		
		System.out.println("Type the Vehicule state: \n1. New \n2. Used");
		int chooseState = reader.nextInt() ;
		
		String state = "" ;
		String plate = "" ;
		double driven = -1 ;
		if (chooseState == 1) {
			state = "New" ;
		} else if(chooseState == 2) {
			
			state = "Used" ;
			System.out.println("Type the Vehicule plate: ") ;
			plate = reader.nextLine() ;
			plate = reader.nextLine() ;
			System.out.println("Type the kilometers driven: ") ;
			driven = reader.nextDouble() ;
			
		}
		
		double price = 0 ;
		
		int year = 0 ;
		
		int[][] image = null ;
		
		String code = "0" ;
		
		System.out.println("You want to register the vehicule a document? \n1. Yes \n2. No");
		int chooseWantDocument = reader.nextInt() ;
		
		if (chooseWantDocument == 1) {
			System.out.println("Type the Vehicule document type: \n1. SOAT \n2. TechnoMecanic \n3. Property card");
			int chooseDocumentType = reader.nextInt() ;
			
			if (chooseDocumentType == 1) {
				
				price = 0 ;
				
				System.out.println("Type the Document year: ");
				
				year = reader.nextInt() ;
				
				image = controller.createDocumentMatrix() ;
				
				System.out.println("\nDocument image: " + "\n" + controller.showDocumentMatrix(image)) ;
				
				System.out.println("\nDocument code: " + "\n" + controller.showDocumentCode(chooseDocumentType, image)) ;
				
				System.out.println("\nIf you want to register a new Document return to main menu.") ;
				
				code = controller.showDocumentCode(chooseDocumentType, image) ;
				
			} else if (chooseDocumentType == 2) {
				
				price = 0 ;
				
				System.out.println("Type the Document year: ");
				
				year = reader.nextInt() ;
				
				image = controller.createDocumentMatrix() ;
				
				System.out.println("\nDocument image: " + "\n" + controller.showDocumentMatrix(image)) ;
				
				System.out.println("\nDocument code: " + "\n" + controller.showDocumentCode(chooseDocumentType, image)) ;
				
				System.out.println("\nIf you want to register a new Document return to main menu.") ;
				
				code = controller.showDocumentCode(chooseDocumentType, image) ;
				
			} else if (chooseDocumentType == 3) {
				
				price = 0 ;
				
				System.out.println("Type the Document year: ");
				
				year = reader.nextInt() ;
				
				image = controller.createDocumentMatrix() ;
				
				System.out.println("\nDocument image: " + "\n" + controller.showDocumentMatrix(image)) ;
				
				System.out.println("\nDocument code: " + "\n" + controller.showDocumentCode(chooseDocumentType, image)) ;
				
				code = controller.showDocumentCode(chooseDocumentType, image) ;
				
				System.out.println("\nIf you want to register a new Document return to main menu.") ;
				
			}
			
		} 
		
		System.out.println("\n");
		
		System.out.println("Type the Vehicule type: \n1. Car \n2. Motorcycle");
		
		int chooseVehiculeType = reader.nextInt() ;
		String type = "" ;
		int door = -1 ;
		boolean hasTintedWindows = false ;
		double capacity = -1 ;
		double fuelUse = -1 ;
		
		if (chooseVehiculeType == 1) {
			
			System.out.println("Choose the Car type: \n1. Sedan \n2. Pick-up Truck") ;
			int chooseCarType = reader.nextInt() ;
			
			if (chooseCarType == 1) {
				type = "Sedan" ;
			} else if (chooseCarType == 2) {
				type = "Pick-up Truck" ;
			}
			
			System.out.println("Type the Car number of doors: ") ;
			door = reader.nextInt() ;
			
			System.out.println("Does the Car has tinted windows? \n1. Yes \n2. No") ;
			int chooseWindows = reader.nextInt() ;
			
			if (chooseWindows == 1) {
				hasTintedWindows = true ;
			} else if (chooseWindows == 2) {
				hasTintedWindows = false ;
			}
			
			System.out.println("Choose the Car subtype: \n1. Electric Car \n2. Gasoline Car \n3. Hybrid Car") ;
			int chooseSubType = reader.nextInt() ;
			
			String chargeType = "" ;
			double duration = -1 ;
			double batteryConsumption = -1 ;
			double tankCapacity = -1 ;
			String gasolineType = "" ;
			double gasolineConsumption = -1 ;
			
			if (chooseSubType == 1) {
				
				System.out.println("Choose the Electric Car charge type: \n1. Fast \n2. Regular") ;
				int chooseChargeType = reader.nextInt() ;
				
				if (chooseChargeType == 1) {
					chargeType = "Fast" ;
				} else if (chooseChargeType == 2) {
					chargeType = "Regular" ;
				}
				
				System.out.println("Type the Electric Car battery duration(watts): ") ;
				duration = reader.nextDouble() ;
				
				System.out.println("Electric Car battery per kilometer(watts/kilometer): ") ;
				
				if (chargeType == "Fast"){
					batteryConsumption = (duration+13)*(cylinder/100) ;
					System.out.println(batteryConsumption) ;
				} else if (chargeType == "Regular"){
					batteryConsumption = (duration+18)*(cylinder/100) ;
					System.out.println(batteryConsumption) ;
				}
		
				
				if (controller.registerElectricCar(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows, chargeType, duration, batteryConsumption)) {

					System.out.println("Electric car registered successfully");

				} else {

					System.out.println("Error, Electric car couldn't be registered");
				}
				
			} else if (chooseSubType == 2) {
				
				System.out.println("Type the Gasoline Car tank capacity (gallons): ") ;
				tankCapacity = reader.nextDouble() ;
				
				System.out.println("Choose the Gasoline Car gasoline type: \n1. Extra \n2. Regular \n3. Diesel") ;
				int chooseGasolineType = reader.nextInt() ;
				
				if (chooseGasolineType == 1) {
					gasolineType = "Extra" ;
				} else if (chooseGasolineType == 2) {
					gasolineType = "Regular" ;
				} else if (chooseGasolineType == 3) {
					gasolineType = "Diesel" ;
				}
				
				System.out.println("Gasoline Car consumption per kilometer(gallons/kilometer): ") ;
				
				gasolineConsumption = (tankCapacity)*(cylinder/150) ;
				System.out.println(gasolineConsumption) ;
				
				if (controller.registerGasolineCar(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows, tankCapacity, gasolineType, gasolineConsumption)) {

					System.out.println("Gasoline car registered successfully");

				} else {

					System.out.println("Error, Gasoline car couldn't be registered");
				}
				
			} else if (chooseSubType == 3) {
				
				System.out.println("Type the Hybrid Car tank capacity (gallons): ") ;
				tankCapacity = reader.nextDouble() ;
				
				System.out.println("Choose the Hybrid Car gasoline type: \n1. Extra \n2. Regular \n3. Diesel") ;
				int chooseGasolineType = reader.nextInt() ;
				
				if (chooseGasolineType == 1) {
					gasolineType = "Extra" ;
				} else if (chooseGasolineType == 2) {
					gasolineType = "Regular" ;
				} else if (chooseGasolineType == 3) {
					gasolineType = "Diesel" ;
				}
				
				System.out.println("Gasoline Car consumption per kilometer(gallons/kilometer): ") ;
				
				gasolineConsumption = (tankCapacity)*(cylinder/180) ;
				System.out.println(gasolineConsumption) ;
				
				System.out.println("Choose the Hybrid Car charge type: \n1. Fast \n2. Regular") ;
				int chooseChargeType = reader.nextInt() ;
				
				if (chooseChargeType == 1) {
					chargeType = "Fast" ;
				} else if (chooseChargeType == 2) {
					chargeType = "Regular" ;
				}
				
				System.out.println("Type the Hybrid Car battery duration(watts): ") ;
				duration = reader.nextDouble() ;
				
				System.out.println("Hybrid Car battery per kilometer(watts/kilometer): ") ;
				
				if (chargeType == "Fast"){
					batteryConsumption = (duration)*(cylinder/200) ;
					System.out.println(batteryConsumption) ;
				} else if (chargeType == "Regular"){
					batteryConsumption = (duration+7)*(cylinder/200) ;
					System.out.println(batteryConsumption) ;
				}
				
				if (controller.registerHybridCar(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, door, hasTintedWindows, tankCapacity, gasolineType, gasolineConsumption, chargeType, duration, batteryConsumption)) {

					System.out.println("Hybrid car registered successfully");

				} else {

					System.out.println("Error, Hybrid car couldn't be registered");
				}
			}
			
		} else if(chooseVehiculeType == 2) {
			
			System.out.println("Choose the motorcycle type: \n1. Standar \n2. Sportive \n3. Scooter \n4. Cross ");
			
			int chooseMotorcycleType = reader.nextInt() ;
			
			if (chooseMotorcycleType == 1) {
				type = "Standar" ;
			} else if (chooseMotorcycleType == 2) {
				type = "Sportive" ;
			} else if (chooseMotorcycleType == 3) {
				type = "Scooter" ;
			} else if (chooseMotorcycleType == 4) {
				type = "Cross" ;
			}
			
			System.out.println("Type the tank capacity (gallon): ");
			
			capacity = reader.nextDouble();
			
			System.out.println("Fuel use (gallons per Km): ");
			
			fuelUse = (capacity)*(cylinder/75) ;
			System.out.println(fuelUse) ;
			
			if (controller.registerMotorcycle(brand, model, basePrice, additionalDiscount, cylinder, state, plate, driven, code, price, year, image, type, capacity, fuelUse)) {

				System.out.println("Motorcycle registered successfully");

			} else {

				System.out.println("Error, Motorcycle couldn't be registered");
			}
			
			
		}
		
	}
	
	private static void showParkingMap() {
		System.out.println(controller.showParkingSlots()) ;
	}
	
	private static void showVehiculeStatus() {
		
		System.out.println("Choose the Vehicule you want to see the document status: ");
		
		System.out.println(controller.showVehiculeList()) ;
		
		int id = reader.nextInt()-1 ;
		
		System.out.println(controller.showVehiculeDocumentStatus(id)) ;
	}
	
	private static void calculateVehiculeTotalPrice() {
		
		System.out.println("Choose the Vehicule you want to calculate the total selling price: ");
		
		System.out.println(controller.showVehiculeList()) ;
		
		int id = reader.nextInt()-1 ;
		
		System.out.println("You want to make an aditional custom discount? \n1. Yes \n2. No");
		
		int desition = reader.nextInt() ;
		
		double aditional = 0 ;
		
		if (desition == 1) {
			System.out.println("Type the aditional custom discount(example: 2%=0.02): ");
			aditional = reader.nextDouble() ;
		}
		
		System.out.println("Vehicule selling price: " + controller.showVehiculeTotalPrice(id, desition, aditional));
	}
	
}

